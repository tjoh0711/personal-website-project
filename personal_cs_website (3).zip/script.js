window.addEventListener('scroll', () => {
  const sections = document.querySelectorAll('.section');
  sections.forEach(sec => {
    const rect = sec.getBoundingClientRect();
    if (rect.top < window.innerHeight - 100) {
      sec.classList.add('visible');
    }
  });
});

document.querySelectorAll('.section').forEach(sec => {
  sec.classList.add('hidden');
});

const style = document.createElement('style');
style.innerHTML = `
.hidden { opacity: 0; transform: translateY(50px); transition: all 0.6s ease; }
.visible { opacity: 1; transform: translateY(0); }
`;
document.head.appendChild(style);
